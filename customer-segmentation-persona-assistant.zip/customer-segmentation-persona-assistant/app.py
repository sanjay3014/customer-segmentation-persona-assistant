import gradio as gr
import pickle
import pandas as pd


# ==============================
# Load Saved Model Files
# ==============================

with open("customer_segmentation_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("customer_scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

with open("feature_columns.pkl", "rb") as f:
    feature_columns = pickle.load(f)


# ==============================
# Segment Explanation Function
# ==============================

def explain_segment(cluster):
    explanations = {
        0: """
Persona: Budget Explorer

Behavior:
This customer has low or moderate activity and may be price-sensitive.

Marketing Strategy:
Offer coupons, discounts, value bundles, and flash sale campaigns.
""",

        1: """
Persona: Premium Buyer

Behavior:
This customer interacts with higher-priced products and may have strong buying potential.

Marketing Strategy:
Promote premium products, exclusive launches, VIP offers, and extended warranty plans.
""",

        2: """
Persona: Brand Explorer

Behavior:
This customer explores multiple brands and categories.

Marketing Strategy:
Use brand-based recommendations, comparison offers, and loyalty benefits.
""",

        3: """
Persona: Window Shopper / Cart Abandoner

Behavior:
This customer browses products or adds items to cart but may not complete purchases.

Marketing Strategy:
Use retargeting ads, cart recovery messages, reminder emails, and limited-time discounts.
"""
    }

    return explanations.get(cluster, "No explanation available for this cluster.")


# ==============================
# Prediction Function
# ==============================

def predict_segment(
    total_events,
    category_diversity,
    avg_price,
    brand_affinity,
    sessions,
    view,
    cart,
    purchase
):
    # Avoid division by zero
    if total_events <= 0:
        return "Total Events must be greater than 0."

    # Calculate rate features
    cart_rate = cart / total_events
    purchase_rate = purchase / total_events

    # Create input dataframe
    user_data = pd.DataFrame({
        "total_events": [total_events],
        "category_diversity": [category_diversity],
        "avg_price": [avg_price],
        "brand_affinity": [brand_affinity],
        "sessions": [sessions],
        "view": [view],
        "cart": [cart],
        "purchase": [purchase],
        "cart_rate": [cart_rate],
        "purchase_rate": [purchase_rate]
    })

    # Keep same feature order as training
    user_data = user_data[feature_columns]

    # Scale input data
    scaled_data = scaler.transform(user_data)

    # Predict cluster
    cluster = model.predict(scaled_data)[0]

    # Get explanation
    explanation = explain_segment(cluster)

    result = f"""
Predicted Cluster: {cluster}

{explanation}

Calculated Rates:
Cart Rate: {cart_rate:.2f}
Purchase Rate: {purchase_rate:.2f}
"""

    return result


# ==============================
# Gradio App Interface
# ==============================

app = gr.Interface(
    fn=predict_segment,

    inputs=[
        gr.Number(label="Total Events", value=5),
        gr.Number(label="Category Diversity", value=2),
        gr.Number(label="Average Product Price", value=300),
        gr.Number(label="Brand Affinity", value=2),
        gr.Number(label="Number of Sessions", value=1),
        gr.Number(label="View Count", value=4),
        gr.Number(label="Cart Count", value=1),
        gr.Number(label="Purchase Count", value=0)
    ],

    outputs=gr.Textbox(label="Customer Segment Result", lines=15),

    title="AI Customer Segmentation Assistant",

    description="""
Enter customer behavior details to predict the customer segment and get persona-based marketing recommendations.
"""
)


# ==============================
# Launch App
# ==============================

if __name__ == "__main__":
    app.launch()
