# AI Customer Segmentation and Persona Assistant

## Project Overview

This project analyzes ecommerce customer behavior and segments customers into meaningful groups using K-Means clustering.

The project also creates customer personas and marketing recommendations for each segment. A Gradio app is included to predict the segment of a new customer based on behavior inputs.

## Business Problem

Ecommerce businesses collect large amounts of customer activity data, but raw logs do not directly show customer intent.

This project helps identify customer groups such as premium buyers, cart abandoners, window shoppers, brand explorers, and budget explorers.

## Objectives

- Analyze ecommerce customer behavior
- Identify popular product categories and brands
- Create customer-level behavioral features
- Apply K-Means clustering
- Generate customer personas
- Provide marketing recommendations
- Build a Gradio prediction app

## Tools and Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- SQLite
- Gradio
- Jupyter Notebook

## Project Workflow

1. Data loading from SQLite database
2. Data cleaning
3. Missing value handling
4. Exploratory data analysis
5. Feature engineering
6. Feature scaling
7. K-Means clustering
8. Cluster evaluation
9. PCA visualization
10. Persona generation
11. Marketing recommendations
12. Gradio app deployment

## Features Used for Clustering

- total_events
- category_diversity
- avg_price
- brand_affinity
- sessions
- view
- cart
- purchase
- cart_rate
- purchase_rate

## Customer Personas

The project identifies customer personas such as:

- Premium Buyer
- Cart Abandoner
- Window Shopper
- Brand Explorer
- Budget Explorer

## How to Run This Project

### 1. Install required libraries

```bash
pip install -r requirements.txt
